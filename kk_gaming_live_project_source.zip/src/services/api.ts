import type {
  User,
  Conversation,
  Message,
  BroadcastAnnouncement,
  AuditLog,
  SystemStats,
  PaginatedResult,
  UserRole,
  UserStatus,
} from '../types/index.ts';

let currentUserId: string = 'saifur-super-admin-01';

export function setApiUserId(id: string) {
  currentUserId = id;
}

export function getApiUserId(): string {
  return currentUserId;
}

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'x-user-id': currentUserId,
});

export const api = {
  // Auth
  async getCurrentUser(): Promise<{ user: User }> {
    const res = await fetch('/api/auth/me', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch user');
    return res.json();
  },

  async login(params: { userId?: string; email?: string; phone?: string }): Promise<{ success: boolean; user: User }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    return data;
  },

  async signup(params: { name: string; phone?: string; email?: string; about?: string }): Promise<{ success: boolean; user: User }> {
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Signup failed');
    return data;
  },

  async updateProfile(userId: string, data: { name?: string; avatar?: string; about?: string; phone?: string }): Promise<{ success: boolean; user: User }> {
    const res = await fetch(`/api/users/${userId}/profile`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!res.ok) throw new Error(result.error || 'Failed to update profile');
    return result;
  },

  // System Stats
  async getStats(): Promise<SystemStats> {
    const res = await fetch('/api/users/stats', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch stats');
    return res.json();
  },

  // Users Directory (10,000+ users query with pagination & filters)
  async getUsers(params: {
    page?: number;
    limit?: number;
    search?: string;
    role?: string;
    status?: string;
  }): Promise<PaginatedResult<User> & { queryDurationMs: number }> {
    const query = new URLSearchParams();
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    if (params.search) query.set('search', params.search);
    if (params.role) query.set('role', params.role);
    if (params.status) query.set('status', params.status);

    const res = await fetch(`/api/users?${query.toString()}`, { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch users directory');
    return res.json();
  },

  // Available Admins for General Users
  async getAdmins(): Promise<{ admins: User[] }> {
    const res = await fetch('/api/admins', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch admins');
    return res.json();
  },

  // Role Promotion / Demotion (Super Admin Only)
  async updateUserRole(targetUserId: string, newRole: UserRole): Promise<{ success: boolean; user: User; message: string }> {
    const res = await fetch(`/api/users/${targetUserId}/role`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ newRole }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update user role');
    return data;
  },

  // Moderate User (Kick / Ban / Unban)
  async updateUserStatus(targetUserId: string, status: UserStatus): Promise<{ success: boolean; user: User }> {
    const res = await fetch(`/api/users/${targetUserId}/status`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update user status');
    return data;
  },

  // Conversations
  async getConversations(): Promise<{ conversations: Conversation[] }> {
    const res = await fetch('/api/conversations', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch conversations');
    return res.json();
  },

  async startConversation(targetUserId: string): Promise<{ conversation: Conversation }> {
    const res = await fetch('/api/conversations/start', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ targetUserId }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to start conversation');
    return data;
  },

  async getMessages(conversationId: string): Promise<{ messages: Message[] }> {
    const res = await fetch(`/api/conversations/${conversationId}/messages`, { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch messages');
    return res.json();
  },

  async sendMessage(params: {
    conversationId: string;
    content: string;
    type?: 'text' | 'image' | 'audio' | 'document';
    media?: any;
  }): Promise<{ success: boolean; message: Message }> {
    const res = await fetch('/api/messages/send', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to send message');
    return data;
  },

  async markAsRead(conversationId: string): Promise<{ success: boolean }> {
    const res = await fetch('/api/messages/read', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ conversationId }),
    });
    if (!res.ok) throw new Error('Failed to mark read');
    return res.json();
  },

  // Broadcasts
  async getBroadcasts(): Promise<{ broadcasts: BroadcastAnnouncement[] }> {
    const res = await fetch('/api/broadcasts', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch broadcasts');
    return res.json();
  },

  async sendBroadcast(params: {
    title: string;
    content: string;
    priority?: 'normal' | 'important' | 'urgent';
  }): Promise<{ success: boolean; broadcast: BroadcastAnnouncement }> {
    const res = await fetch('/api/broadcasts', {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to send broadcast');
    return data;
  },

  // Audit Logs
  async getAuditLogs(): Promise<{ auditLogs: AuditLog[] }> {
    const res = await fetch('/api/audit-logs', { headers: getHeaders() });
    if (!res.ok) throw new Error('Failed to fetch audit logs');
    return res.json();
  },
};

// ==========================================
// WebSocket Realtime Manager
// ==========================================

type WsEventListener = (event: any) => void;

class RealtimeSocket {
  private socket: WebSocket | null = null;
  private listeners: Set<WsEventListener> = new Set();
  private reconnectTimer: any = null;
  private userId: string | null = null;
  private messageQueue: string[] = [];

  connect(userId: string) {
    this.userId = userId;

    // 1. If socket is already OPEN, simply authenticate
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      this.safeSend({ type: 'auth', userId });
      return;
    }

    // 2. If socket is currently CONNECTING, do not create another one!
    // The onopen handler will automatically dispatch auth for this.userId.
    if (this.socket && this.socket.readyState === WebSocket.CONNECTING) {
      return;
    }

    // 3. Clean up any closing/closed socket before creating a fresh connection
    if (this.socket) {
      try {
        this.socket.onopen = null;
        this.socket.onmessage = null;
        this.socket.onerror = null;
        this.socket.onclose = null;
        this.socket.close();
      } catch (e) {
        // ignore
      }
      this.socket = null;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(wsUrl);
      this.socket = ws;

      ws.onopen = () => {
        // Only run for the active socket
        if (this.socket !== ws) return;

        if (this.userId) {
          this.safeSend({ type: 'auth', userId: this.userId });
        }
        this.flushQueue();
      };

      ws.onmessage = (event) => {
        if (this.socket !== ws) return;
        try {
          const data = JSON.parse(event.data);
          this.listeners.forEach((listener) => listener(data));
        } catch (e) {
          console.error('Socket message parse error', e);
        }
      };

      ws.onclose = () => {
        if (this.socket === ws) {
          this.socket = null;
        }
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = setTimeout(() => {
          if (this.userId) this.connect(this.userId);
        }, 3000);
      };

      ws.onerror = (err) => {
        console.warn('Socket connection note:', err);
      };
    } catch (e) {
      console.warn('Socket connect failed, will retry', e);
    }
  }

  private safeSend(data: object | string) {
    const payload = typeof data === 'string' ? data : JSON.stringify(data);
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      try {
        this.socket.send(payload);
      } catch (e) {
        console.warn('SafeSend error:', e);
      }
    } else {
      this.messageQueue.push(payload);
    }
  }

  private flushQueue() {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      while (this.messageQueue.length > 0) {
        const item = this.messageQueue.shift();
        if (item) {
          try {
            this.socket.send(item);
          } catch (e) {
            console.warn('Flush queue error:', e);
          }
        }
      }
    }
  }

  subscribe(listener: WsEventListener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  sendTyping(conversationId: string, recipientId: string, isTyping: boolean) {
    this.safeSend({
      type: 'typing',
      conversationId,
      recipientId,
      isTyping,
    });
  }

  disconnect() {
    clearTimeout(this.reconnectTimer);
    if (this.socket) {
      try {
        this.socket.onopen = null;
        this.socket.onmessage = null;
        this.socket.onerror = null;
        this.socket.onclose = null;
        this.socket.close();
      } catch (e) {
        // ignore
      }
      this.socket = null;
    }
  }
}

export const realtimeSocket = new RealtimeSocket();
