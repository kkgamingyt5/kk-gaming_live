export type UserRole = 'super_admin' | 'secondary_admin' | 'general_user';

export type UserStatus = 'active' | 'banned' | 'muted' | 'offline';

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string;
  role: UserRole;
  status: UserStatus;
  about?: string;
  createdAt: string;
  lastSeen: string;
  isOnline: boolean;
  isImmutableOwner?: boolean; // Rigorously protected Super Admin flag
}

export type MessageType = 'text' | 'image' | 'audio' | 'document' | 'system';

export type MessageStatus = 'sent' | 'delivered' | 'read';

export interface MessageMedia {
  url: string;
  fileName?: string;
  fileSize?: string;
  duration?: number; // For audio in seconds
  mimeType?: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  recipientId: string;
  type: MessageType;
  content: string;
  media?: MessageMedia;
  status: MessageStatus;
  timestamp: string;
  readAt?: string;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participants: User[];
  lastMessage?: Message;
  unreadCount: number;
  updatedAt: string;
  isSupportTicket?: boolean;
}

export interface BroadcastAnnouncement {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  title: string;
  content: string;
  priority: 'normal' | 'important' | 'urgent';
  createdAt: string;
  recipientCount: number;
  readsCount: number;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: 'promote_admin' | 'demote_admin' | 'ban_user' | 'unban_user' | 'broadcast_sent' | 'attempted_owner_breach';
  targetUserId?: string;
  targetUserName?: string;
  details: string;
  timestamp: string;
  status: 'allowed' | 'blocked_by_guard';
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface SystemStats {
  totalUsers: number;
  activeNow: number;
  superAdminCount: number;
  secondaryAdminCount: number;
  generalUsersCount: number;
  bannedCount: number;
  totalMessagesSent: number;
  totalBroadcasts: number;
}
