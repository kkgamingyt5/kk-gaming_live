import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { ChatProvider, useChat } from './context/ChatContext.tsx';
import { RoleDemoBanner } from './components/RoleDemoBanner.tsx';
import { Sidebar } from './components/whatsapp/Sidebar.tsx';
import { ChatArea } from './components/whatsapp/ChatArea.tsx';
import { AdminDashboard } from './components/admin/AdminDashboard.tsx';
import { BroadcastsViewModal } from './components/modals/BroadcastsViewModal.tsx';
import { NewChatModal } from './components/modals/NewChatModal.tsx';
import { BroadcastModal } from './components/modals/BroadcastModal.tsx';
import { UserProfileModal } from './components/modals/UserProfileModal.tsx';
import { AuthModal } from './components/modals/AuthModal.tsx';
import { CallModal } from './components/modals/CallModal.tsx';
import { OfflineIndicator } from './components/pwa/OfflineIndicator.tsx';

function MainApp() {
  const { darkMode } = useAuth();
  const { activeTab } = useChat();

  // Modals state
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Call simulation state
  const [callState, setCallState] = useState<{
    isOpen: boolean;
    type: 'audio' | 'video';
    targetName: string;
  }>({
    isOpen: false,
    type: 'audio',
    targetName: 'Support Desk',
  });

  const handleStartCall = (type: 'audio' | 'video', targetName: string) => {
    setCallState({
      isOpen: true,
      type,
      targetName,
    });
  };

  return (
    <div className={`h-screen flex flex-col overflow-hidden ${darkMode ? 'bg-[#0c1317]' : 'bg-[#d1d7db]'}`}>
      {/* 1. Quick Role Switcher Banner */}
      <RoleDemoBanner onOpenAuthModal={() => setIsAuthModalOpen(true)} />

      {/* 2. Main WhatsApp Interface Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          onOpenNewChatModal={() => setIsNewChatOpen(true)}
          onOpenProfileModal={() => setIsProfileOpen(true)}
          onOpenBroadcastModal={() => setIsBroadcastModalOpen(true)}
        />

        {/* Dynamic Main View */}
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {activeTab === 'chats' && (
            <ChatArea
              onStartCall={handleStartCall}
              onOpenNewChatModal={() => setIsNewChatOpen(true)}
            />
          )}

          {activeTab === 'admin_dashboard' && <AdminDashboard />}

          {activeTab === 'broadcasts' && (
            <BroadcastsViewModal
              onOpenCreateBroadcast={() => setIsBroadcastModalOpen(true)}
            />
          )}
        </div>
      </div>

      {/* Modals */}
      <NewChatModal
        isOpen={isNewChatOpen}
        onClose={() => setIsNewChatOpen(false)}
      />

      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />

      <BroadcastModal
        isOpen={isBroadcastModalOpen}
        onClose={() => setIsBroadcastModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <CallModal
        isOpen={callState.isOpen}
        type={callState.type}
        targetName={callState.targetName}
        onClose={() => setCallState((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Offline Connectivity Notification */}
      <OfflineIndicator />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ChatProvider>
        <MainApp />
      </ChatProvider>
    </AuthProvider>
  );
}
