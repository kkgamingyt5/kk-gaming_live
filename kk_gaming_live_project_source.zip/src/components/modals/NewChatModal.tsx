import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useChat } from '../../context/ChatContext.tsx';
import { api } from '../../services/api.ts';
import {
  X,
  Search,
  Shield,
  Crown,
  User as UserIcon,
  MessageSquare,
  Lock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import type { User } from '../../types/index.ts';

interface NewChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewChatModal: React.FC<NewChatModalProps> = ({ isOpen, onClose }) => {
  const { currentUser } = useAuth();
  const { startChatWithUser } = useChat();

  const [admins, setAdmins] = useState<User[]>([]);
  const [directoryUsers, setDirectoryUsers] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const isGeneralUser = currentUser?.role === 'general_user';

  useEffect(() => {
    if (!isOpen) return;

    async function loadContacts() {
      setIsLoading(true);
      try {
        if (isGeneralUser) {
          // General user can ONLY fetch admins
          const res = await api.getAdmins();
          setAdmins(res.admins);
        } else {
          // Admin can search all users
          const res = await api.getUsers({ limit: 25, search });
          setDirectoryUsers(res.items);
        }
      } catch (e) {
        console.error('Failed to load contacts', e);
      } finally {
        setIsLoading(false);
      }
    }

    loadContacts();
  }, [isOpen, isGeneralUser, search]);

  if (!isOpen || !currentUser) return null;

  const handleSelectUser = async (user: User) => {
    try {
      await startChatWithUser(user.id);
      onClose();
    } catch (e: any) {
      // Handled in chat context
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {isGeneralUser ? 'Message Official Support & Admins' : 'Start New Conversation'}
              </h3>
              <p className="text-xs text-slate-400">
                {isGeneralUser ? 'Select an authorized administrator to reach out to' : 'Search any member in the 10,000+ directory'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Policy notice for General Users */}
        {isGeneralUser && (
          <div className="p-3.5 mx-4 mt-4 rounded-xl bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200 flex items-start gap-2.5">
            <Lock className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">RBAC Security Policy:</span>
              <p className="text-slate-300 mt-0.5">
                General Users are restricted from contacting other General Users directly. You can initiate 1-on-1 private inquiries with the Super Admin or Secondary Support Admins below.
              </p>
            </div>
          </div>
        )}

        {/* Search Bar (for Admins) */}
        {!isGeneralUser && (
          <div className="p-4 border-b border-slate-800">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by name, phone, or email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 pl-9 pr-4 py-2 rounded-xl text-xs sm:text-sm text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>
        )}

        {/* Contacts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {isLoading ? (
            <div className="py-12 text-center text-slate-400 text-xs">Loading available contacts...</div>
          ) : isGeneralUser ? (
            // Admins list for General User
            admins.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">No admins currently online.</div>
            ) : (
              admins.map((admin) => (
                <div
                  key={admin.id}
                  onClick={() => handleSelectUser(admin)}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img
                        src={admin.avatar}
                        alt={admin.name}
                        className="w-11 h-11 rounded-full object-cover"
                      />
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-slate-800" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 font-semibold text-white text-sm">
                        <span>{admin.name}</span>
                        {admin.role === 'super_admin' ? (
                          <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                            <Crown className="w-3 h-3 text-amber-400" />
                            Super Admin (Owner)
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                            <Shield className="w-3 h-3 text-emerald-400" />
                            Secondary Admin
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">{admin.about}</div>
                    </div>
                  </div>

                  <button className="px-3 py-1.5 rounded-lg bg-emerald-600 group-hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs transition-colors">
                    Chat
                  </button>
                </div>
              ))
            )
          ) : (
            // Full Directory for Admins
            directoryUsers.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">No users found.</div>
            ) : (
              directoryUsers.map((user) => (
                <div
                  key={user.id}
                  onClick={() => handleSelectUser(user)}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-semibold text-white text-sm flex items-center gap-1.5">
                        <span>{user.name}</span>
                        {user.role === 'super_admin' && (
                          <Crown className="w-3.5 h-3.5 text-amber-400" />
                        )}
                        {user.role === 'secondary_admin' && (
                          <Shield className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                      </div>
                      <div className="text-xs text-slate-400">{user.phone} • {user.email}</div>
                    </div>
                  </div>

                  <button className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-medium transition-colors">
                    Start Chat
                  </button>
                </div>
              ))
            )
          )}
        </div>
      </div>
    </div>
  );
};
