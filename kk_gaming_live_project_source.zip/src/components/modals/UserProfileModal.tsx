import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  X,
  Crown,
  Shield,
  User as UserIcon,
  Phone,
  Mail,
  Calendar,
  Lock,
  Camera,
  Upload,
  Link,
  Check,
  Sparkles,
  Edit2,
  Save,
} from 'lucide-react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  {
    name: 'KK Gaming YT Store Official',
    url: '/kk_gaming_logo.jpg',
  },
  {
    name: 'Cyber Esports Gold Crown',
    url: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Pro Gamer Neon Headset',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Streamer Red Glow',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Elite Player Crest',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Stealth Shadow',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
  },
];

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, updateUserProfile } = useAuth();

  const [isEditingPhoto, setIsEditingPhoto] = useState(false);
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(currentUser?.avatar || '/kk_gaming_logo.jpg');
  const [customUrl, setCustomUrl] = useState('');
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editAbout, setEditAbout] = useState(currentUser?.about || '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen || !currentUser) return null;

  // Handle local image file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Image must be under 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setSelectedAvatar(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleApplyUrl = () => {
    if (customUrl.trim()) {
      setSelectedAvatar(customUrl.trim());
      setCustomUrl('');
    }
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await updateUserProfile({
        avatar: selectedAvatar,
        name: isEditingInfo ? editName : currentUser.name,
        about: isEditingInfo ? editAbout : currentUser.about,
      });
      setSaveSuccess(true);
      setIsEditingPhoto(false);
      setIsEditingInfo(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e: any) {
      alert(`Update failed: ${e.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header Banner */}
        <div className="h-32 bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 relative border-b border-slate-800">
          <div className="absolute inset-0 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:16px_16px] opacity-20" />
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-white/80 hover:text-white p-1.5 rounded-xl bg-black/40 hover:bg-black/60 transition-colors z-10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 pb-6 pt-0 relative flex-1 overflow-y-auto">
          {/* Avatar with Camera Overlay */}
          <div className="relative -mt-16 mb-4 flex justify-between items-end">
            <div className="relative group">
              <img
                src={selectedAvatar}
                alt={currentUser.name}
                className="w-28 h-28 rounded-full object-cover ring-4 ring-slate-900 shadow-2xl bg-slate-950"
              />
              <span className="absolute bottom-1 right-1 w-5 h-5 bg-emerald-500 rounded-full ring-4 ring-slate-900" />

              {/* Change Photo Overlay Button */}
              <button
                type="button"
                onClick={() => setIsEditingPhoto(!isEditingPhoto)}
                className="absolute inset-0 rounded-full bg-black/60 text-white flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer ring-4 ring-emerald-500/50"
                title="تصویر تبدیل کریں (Change Profile Picture)"
              >
                <Camera className="w-6 h-6 mb-1 text-emerald-400" />
                <span className="text-[10px] font-bold tracking-tight">Change</span>
              </button>
            </div>

            <div className="flex flex-col items-end gap-1.5">
              {currentUser.role === 'super_admin' ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 shadow-sm">
                  <Crown className="w-4 h-4 text-amber-400" />
                  Super Admin (Owner)
                </span>
              ) : currentUser.role === 'secondary_admin' ? (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 shadow-sm">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  Secondary Admin
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center gap-1.5 shadow-sm">
                  <UserIcon className="w-4 h-4 text-blue-400" />
                  General User
                </span>
              )}

              <button
                type="button"
                onClick={() => setIsEditingPhoto(!isEditingPhoto)}
                className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 text-xs font-medium flex items-center gap-1 transition-colors"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>پروفائل پکچر تبدیل کریں</span>
              </button>
            </div>
          </div>

          {/* Success notice */}
          {saveSuccess && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>پروفائل اور تصویر کامیابی سے اپڈیٹ ہوگئی! (Profile updated successfully)</span>
            </div>
          )}

          {/* PHOTO CHANGER PANEL */}
          {isEditingPhoto && (
            <div className="mb-5 p-4 rounded-2xl bg-slate-800/80 border border-emerald-500/30 shadow-lg space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  نئی پروفائل تصویر منتخب کریں (Choose Profile Picture)
                </span>
                <button
                  type="button"
                  onClick={() => setIsEditingPhoto(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              {/* Preset Avatars Gallery */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-2">
                  Official Badges & Gaming Avatars
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {PRESET_AVATARS.map((preset, idx) => {
                    const isSelected = selectedAvatar === preset.url;
                    return (
                      <div
                        key={idx}
                        onClick={() => setSelectedAvatar(preset.url)}
                        className={`p-1.5 rounded-xl border cursor-pointer transition-all flex flex-col items-center gap-1 ${
                          isSelected
                            ? 'border-emerald-500 bg-emerald-500/20 ring-2 ring-emerald-400'
                            : 'border-slate-700 bg-slate-900/60 hover:border-slate-600'
                        }`}
                        title={preset.name}
                      >
                        <img
                          src={preset.url}
                          alt={preset.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <span className="text-[9px] text-slate-300 truncate w-full text-center">
                          {idx === 0 ? 'KK Gaming' : preset.name.split(' ')[0]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Upload Local File or Enter URL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-700/60">
                {/* Upload Button */}
                <label className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-slate-900 hover:bg-slate-750 border border-slate-700 cursor-pointer text-xs font-medium text-slate-200 transition-colors">
                  <Upload className="w-4 h-4 text-emerald-400" />
                  <span>Upload from device</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                {/* Paste URL */}
                <div className="flex items-center gap-1">
                  <div className="relative flex-1">
                    <Link className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="url"
                      placeholder="Paste image link..."
                      value={customUrl}
                      onChange={(e) => setCustomUrl(e.target.value)}
                      className="w-full pl-8 pr-2 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleApplyUrl}
                    className="px-2.5 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-medium"
                  >
                    Set
                  </button>
                </div>
              </div>

              {/* Save Photo CTA */}
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleSaveProfile}
                  disabled={isSaving}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-colors"
                >
                  <Save className="w-3.5 h-3.5" />
                  {isSaving ? 'Saving...' : 'تصویر محفوظ کریں (Save Picture)'}
                </button>
              </div>
            </div>
          )}

          {/* Name & Bio */}
          <div className="mb-4">
            {!isEditingInfo ? (
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    {currentUser.name}
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">{currentUser.about || 'Available'}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEditName(currentUser.name);
                    setEditAbout(currentUser.about || '');
                    setIsEditingInfo(true);
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title="Edit Name & About"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="space-y-3 p-3.5 rounded-xl bg-slate-800/80 border border-slate-700">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    About / Status
                  </label>
                  <input
                    type="text"
                    value={editAbout}
                    onChange={(e) => setEditAbout(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsEditingInfo(false)}
                    className="px-3 py-1 rounded-lg bg-slate-700 text-slate-300 text-xs font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveProfile}
                    disabled={isSaving}
                    className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                  >
                    {isSaving ? 'Saving...' : 'Save Info'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Super Admin Immutable Safeguard Seal */}
          {currentUser.role === 'super_admin' && (
            <div className="p-3.5 mb-4 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-200 space-y-1">
              <div className="font-semibold flex items-center gap-1.5 text-amber-300">
                <Lock className="w-3.5 h-3.5" /> Immutable Owner Privilege (KK Gaming Live)
              </div>
              <p className="text-[11px] text-amber-200/90 leading-relaxed">
                This account is recognized as the supreme system creator. Demotion, kick, or ban actions targeting this user are strictly rejected by the server kernel.
              </p>
            </div>
          )}

          {/* Details list */}
          <div className="space-y-3 pt-2 border-t border-slate-800 text-xs text-slate-300">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-slate-400">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-slate-500 font-medium">PHONE NUMBER / WHATSAPP</div>
                <div className="text-slate-200 font-mono">{currentUser.phone}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-slate-500 font-medium">EMAIL ADDRESS</div>
                <div className="text-slate-200">{currentUser.email}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 text-slate-400">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] text-slate-500 font-medium">ACCOUNT CREATED</div>
                <div className="text-slate-200">{new Date(currentUser.createdAt).toLocaleDateString()}</div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
