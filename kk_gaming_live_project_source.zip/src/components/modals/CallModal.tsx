import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff, Volume2 } from 'lucide-react';

interface CallModalProps {
  isOpen: boolean;
  type: 'audio' | 'video';
  targetName: string;
  onClose: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  type,
  targetName,
  onClose,
}) => {
  const [callStatus, setCallStatus] = useState<'ringing' | 'connected'>('ringing');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(type === 'audio');

  useEffect(() => {
    if (!isOpen) {
      setCallStatus('ringing');
      setCallDuration(0);
      return;
    }

    // Connect after 2.5 seconds ringing
    const connectTimer = setTimeout(() => {
      setCallStatus('connected');
    }, 2500);

    return () => clearTimeout(connectTimer);
  }, [isOpen]);

  useEffect(() => {
    let interval: any = null;
    if (callStatus === 'connected') {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callStatus]);

  if (!isOpen) return null;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#111b21] border border-slate-800 rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl flex flex-col items-center justify-between p-8 min-h-[460px] text-white">
        {/* Caller Info */}
        <div className="text-center space-y-2 mt-4">
          <div className="relative inline-block">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
              alt={targetName}
              className={`w-28 h-28 rounded-full object-cover ring-4 ${
                callStatus === 'ringing' ? 'ring-emerald-500 animate-pulse' : 'ring-emerald-400'
              }`}
            />
          </div>

          <h2 className="text-xl font-bold pt-2">{targetName}</h2>
          <p className="text-xs text-emerald-400 font-medium">
            {callStatus === 'ringing' ? (
              <span className="flex items-center justify-center gap-1">
                <Volume2 className="w-4 h-4 animate-bounce" />
                Ringing (WhatsApp Call)...
              </span>
            ) : (
              <span className="font-mono text-sm">{formatDuration(callDuration)}</span>
            )}
          </p>
        </div>

        {/* Video preview simulation */}
        {type === 'video' && !isVideoOff && (
          <div className="w-full my-4 rounded-2xl bg-slate-900 border border-slate-800 p-4 text-center">
            <div className="text-xs text-slate-400">Camera preview active (Encrypted)</div>
          </div>
        )}

        {/* Call Controls */}
        <div className="flex items-center gap-4 mt-8">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-3.5 rounded-full transition-colors ${
              isMuted ? 'bg-red-500 text-white' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {type === 'video' && (
            <button
              onClick={() => setIsVideoOff(!isVideoOff)}
              className={`p-3.5 rounded-full transition-colors ${
                isVideoOff ? 'bg-red-500 text-white' : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
              title={isVideoOff ? 'Turn camera on' : 'Turn camera off'}
            >
              {isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
            </button>
          )}

          <button
            onClick={onClose}
            className="p-4 rounded-full bg-red-600 hover:bg-red-500 text-white shadow-lg transition-transform active:scale-95"
            title="End Call"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
