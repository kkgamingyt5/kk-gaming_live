import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useChat } from '../../context/ChatContext.tsx';
import { Radio, AlertTriangle, Info, Bell, Plus, Shield, Crown, CheckCircle2 } from 'lucide-react';
import type { BroadcastAnnouncement } from '../../types/index.ts';

interface BroadcastsViewModalProps {
  onOpenCreateBroadcast?: () => void;
}

export const BroadcastsViewModal: React.FC<BroadcastsViewModalProps> = ({
  onOpenCreateBroadcast,
}) => {
  const { currentUser } = useAuth();
  const { broadcasts } = useChat();

  const isAdmin = currentUser?.role === 'super_admin' || currentUser?.role === 'secondary_admin';

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-500/20 text-red-300 border border-red-500/40 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-red-400" />
            Urgent Notice
          </span>
        );
      case 'important':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
            <Bell className="w-3 h-3 text-amber-400" />
            Important
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center gap-1">
            <Info className="w-3 h-3 text-blue-400" />
            General Announcement
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="bg-slate-900 border-b border-slate-800 p-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Radio className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Broadcast Announcement Channel</h1>
              <p className="text-xs text-slate-400">
                Official broadcasts dispatched by Platform Super Admin & Support Leads to all members.
              </p>
            </div>
          </div>

          {isAdmin && onOpenCreateBroadcast && (
            <button
              onClick={onOpenCreateBroadcast}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Plus className="w-4 h-4" />
              New Broadcast
            </button>
          )}
        </div>
      </div>

      {/* Broadcasts List */}
      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {broadcasts.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <Radio className="w-12 h-12 mx-auto mb-3 opacity-20 text-emerald-500" />
              <p className="text-base font-medium text-slate-300">No broadcasts at this time</p>
              <p className="text-xs text-slate-500 mt-1">Official announcements from admins will appear here.</p>
            </div>
          ) : (
            broadcasts.map((bc) => (
              <div
                key={bc.id}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all shadow-md space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {getPriorityBadge(bc.priority)}
                    <span className="text-xs text-slate-400">
                      {new Date(bc.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <span>Dispatched by:</span>
                    <span className="font-semibold text-slate-200">{bc.senderName}</span>
                    {bc.senderRole === 'super_admin' ? (
                      <span title="Super Admin"><Crown className="w-3.5 h-3.5 text-amber-400" /></span>
                    ) : (
                      <span title="Secondary Admin"><Shield className="w-3.5 h-3.5 text-emerald-400" /></span>
                    )}
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white mb-1.5">{bc.title}</h3>
                  <p className="text-sm text-slate-300 whitespace-pre-wrap leading-relaxed">
                    {bc.content}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Delivered to all active members
                  </span>
                  <span>{bc.readsCount.toLocaleString()} reads</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
