import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useChat } from '../../context/ChatContext.tsx';
import {
  MessageSquare,
  Radio,
  Shield,
  Plus,
  Search,
  Sun,
  Moon,
  Check,
  CheckCheck,
  Mic,
  Image as ImageIcon,
  FileText,
  Crown,
  User as UserIcon,
  Filter,
} from 'lucide-react';
import type { Conversation, UserRole } from '../../types/index.ts';
import { PWAInstallButton } from '../pwa/PWAInstallButton.tsx';

interface SidebarProps {
  onOpenNewChatModal: () => void;
  onOpenProfileModal: () => void;
  onOpenBroadcastModal: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenNewChatModal,
  onOpenProfileModal,
  onOpenBroadcastModal,
}) => {
  const { currentUser, darkMode, toggleDarkMode } = useAuth();
  const {
    conversations,
    activeConversation,
    selectConversation,
    activeTab,
    setActiveTab,
    unreadBroadcastsCount,
    isTypingMap,
  } = useChat();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'unread' | 'admin'>('all');

  if (!currentUser) return null;

  const isAdmin = currentUser.role === 'super_admin' || currentUser.role === 'secondary_admin';

  // Filter conversations
  const filteredConversations = conversations.filter((conv) => {
    const otherParticipant = conv.participants.find((p) => p.id !== currentUser.id);
    const participantName = otherParticipant?.name || 'Support Chat';

    // Search filter
    const matchesSearch =
      participantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (conv.lastMessage?.content || '').toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    // Type filter
    if (filterType === 'unread') return conv.unreadCount > 0;
    if (filterType === 'admin') {
      return (
        otherParticipant?.role === 'super_admin' ||
        otherParticipant?.role === 'secondary_admin'
      );
    }
    return true;
  });

  const getRoleIcon = (role?: UserRole) => {
    switch (role) {
      case 'super_admin':
        return <span title="Super Admin (Owner)"><Crown className="w-3.5 h-3.5 text-amber-500" /></span>;
      case 'secondary_admin':
        return <span title="Secondary Admin (Support)"><Shield className="w-3.5 h-3.5 text-emerald-500" /></span>;
      default:
        return null;
    }
  };

  const formatTime = (isoString?: string) => {
    if (!isoString) return '';
    const date = new Date(isoString);
    const now = new Date();
    const isToday =
      date.getDate() === now.getDate() &&
      date.getMonth() === now.getMonth() &&
      date.getFullYear() === now.getFullYear();

    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div
      className={`w-full md:w-96 md:min-w-[340px] md:max-w-[420px] flex flex-col h-full border-r ${
        darkMode
          ? 'bg-[#111b21] border-[#222e35] text-[#e9edef]'
          : 'bg-[#ffffff] border-[#e9edef] text-[#111b21]'
      }`}
    >
      {/* Brand Header with KK Gaming Logo */}
      <div
        className={`px-4 py-2.5 flex items-center justify-between border-b ${
          darkMode ? 'bg-[#182229] border-[#222e35]' : 'bg-[#f0f2f5] border-[#e9edef]'
        }`}
      >
        <div className="flex items-center gap-2.5">
          <img
            src="/kk_gaming_logo.jpg"
            alt="KK Gaming Logo"
            className="w-8 h-8 rounded-full object-cover ring-2 ring-amber-400/80 shadow-md"
          />
          <div>
            <div className="font-bold text-xs tracking-tight flex items-center gap-1">
              <span>KK GAMING YT STORE</span>
              <Crown className="w-3 h-3 text-amber-400" />
            </div>
            <div className="text-[10px] text-emerald-400 font-mono">
              AdminGuard Verified
            </div>
          </div>
        </div>

        <div>
          <PWAInstallButton variant="header" />
        </div>
      </div>

      {/* WhatsApp Sidebar Header */}
      <div
        className={`px-4 py-3 flex items-center justify-between border-b ${
          darkMode ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f0f2f5] border-[#e9edef]'
        }`}
      >
        {/* User Profile trigger */}
        <div
          onClick={onOpenProfileModal}
          className="flex items-center gap-3 cursor-pointer group"
          title="View profile & account details"
        >
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-emerald-500/50 group-hover:opacity-90 transition-opacity"
            />
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-[#202c33]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 font-semibold text-sm">
              <span className="truncate max-w-[120px]">{currentUser.name}</span>
              {getRoleIcon(currentUser.role)}
            </div>
            <div className="text-[11px] text-slate-400 capitalize">
              {currentUser.role.replace('_', ' ')}
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1 text-slate-400">
          {/* Admin Dashboard tab trigger */}
          {isAdmin && (
            <button
              onClick={() => setActiveTab('admin_dashboard')}
              className={`p-2 rounded-full transition-colors relative ${
                activeTab === 'admin_dashboard'
                  ? 'text-emerald-400 bg-emerald-500/10'
                  : 'hover:text-slate-200 hover:bg-slate-700/30'
              }`}
              title="Open Admin Management Panel (10k+ Users)"
            >
              <Shield className="w-5 h-5 text-emerald-400" />
            </button>
          )}

          {/* Broadcasts tab trigger */}
          <button
            onClick={() => setActiveTab('broadcasts')}
            className={`p-2 rounded-full transition-colors relative ${
              activeTab === 'broadcasts'
                ? 'text-emerald-400 bg-emerald-500/10'
                : 'hover:text-slate-200 hover:bg-slate-700/30'
            }`}
            title="Broadcast Announcements"
          >
            <Radio className="w-5 h-5" />
            {unreadBroadcastsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full" />
            )}
          </button>

          {/* New Chat Button */}
          <button
            onClick={onOpenNewChatModal}
            className="p-2 rounded-full hover:text-slate-200 hover:bg-slate-700/30 transition-colors"
            title={isAdmin ? 'Start new chat with any user' : 'Contact official Admin'}
          >
            <Plus className="w-5 h-5" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:text-slate-200 hover:bg-slate-700/30 transition-colors"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Nav Tabs (Chats vs Admin Dashboard vs Broadcasts) */}
      <div className={`flex border-b text-xs font-semibold ${darkMode ? 'border-[#222e35]' : 'border-[#e9edef]'}`}>
        <button
          onClick={() => setActiveTab('chats')}
          className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
            activeTab === 'chats'
              ? 'border-emerald-500 text-emerald-500'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Chats ({conversations.length})
        </button>

        <button
          onClick={() => setActiveTab('broadcasts')}
          className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
            activeTab === 'broadcasts'
              ? 'border-emerald-500 text-emerald-500'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Radio className="w-4 h-4" />
          Broadcasts
        </button>

        {isAdmin && (
          <button
            onClick={() => setActiveTab('admin_dashboard')}
            className={`flex-1 py-2.5 text-center flex items-center justify-center gap-1.5 transition-colors border-b-2 ${
              activeTab === 'admin_dashboard'
                ? 'border-emerald-500 text-emerald-500'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-4 h-4" />
            Admin Panel
          </button>
        )}
      </div>

      {/* Search Bar & Filter Chips */}
      <div className="p-3 space-y-2 border-b border-transparent">
        <div
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg ${
            darkMode ? 'bg-[#202c33] text-slate-300' : 'bg-[#f0f2f5] text-slate-700'
          }`}
        >
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search or start new chat"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent text-xs sm:text-sm focus:outline-hidden placeholder:text-slate-400"
          />
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 pt-1 text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              filterType === 'all'
                ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
                : darkMode
                ? 'bg-[#202c33] text-slate-400 hover:text-slate-200'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterType('unread')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              filterType === 'unread'
                ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
                : darkMode
                ? 'bg-[#202c33] text-slate-400 hover:text-slate-200'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            Unread
          </button>
          <button
            onClick={() => setFilterType('admin')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              filterType === 'admin'
                ? 'bg-emerald-600/30 text-emerald-400 border border-emerald-500/40'
                : darkMode
                ? 'bg-[#202c33] text-slate-400 hover:text-slate-200'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            Admins
          </button>
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto">
        {filteredConversations.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs sm:text-sm flex flex-col items-center justify-center h-48">
            <MessageSquare className="w-10 h-10 mb-2 opacity-30 text-emerald-500" />
            <p className="font-medium text-slate-300">No chats found</p>
            <p className="text-xs text-slate-500 mt-1 max-w-[220px]">
              {currentUser.role === 'general_user'
                ? 'Start a private 1-on-1 query with an official Admin.'
                : 'You have no open user conversations.'}
            </p>
            <button
              onClick={onOpenNewChatModal}
              className="mt-3 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              {currentUser.role === 'general_user' ? 'Message Support Admin' : 'New Chat'}
            </button>
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const otherUser = conv.participants.find((p) => p.id !== currentUser.id);
            const isSelected = activeConversation?.id === conv.id;
            const isTyping = isTypingMap[conv.id];

            return (
              <div
                key={conv.id}
                onClick={() => {
                  setActiveTab('chats');
                  selectConversation(conv);
                }}
                className={`flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors relative border-b ${
                  darkMode
                    ? isSelected
                      ? 'bg-[#2a3942] border-[#222e35]'
                      : 'hover:bg-[#202c33]/70 border-[#222e35]/40'
                    : isSelected
                    ? 'bg-[#f0f2f5] border-[#e9edef]'
                    : 'hover:bg-[#f5f6f6] border-[#f0f2f5]'
                }`}
              >
                {/* Avatar with Presence */}
                <div className="relative shrink-0">
                  <img
                    src={
                      otherUser?.avatar ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                    }
                    alt={otherUser?.name || 'Contact'}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  {otherUser?.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full ring-2 ring-[#111b21]" />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="font-medium text-sm truncate">
                        {otherUser?.name || 'Support Desk'}
                      </span>
                      {getRoleIcon(otherUser?.role)}
                    </div>
                    <span
                      className={`text-[11px] shrink-0 ${
                        conv.unreadCount > 0 ? 'text-emerald-400 font-semibold' : 'text-slate-400'
                      }`}
                    >
                      {formatTime(conv.lastMessage?.timestamp || conv.updatedAt)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-slate-400 truncate flex items-center gap-1 max-w-[210px]">
                      {isTyping ? (
                        <span className="text-emerald-400 font-medium italic">typing...</span>
                      ) : conv.lastMessage ? (
                        <>
                          {/* Read Receipts tick mark if outgoing */}
                          {conv.lastMessage.senderId === currentUser.id && (
                            <span className="shrink-0">
                              {conv.lastMessage.status === 'read' ? (
                                <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" />
                              ) : conv.lastMessage.status === 'delivered' ? (
                                <CheckCheck className="w-3.5 h-3.5 text-slate-400" />
                              ) : (
                                <Check className="w-3.5 h-3.5 text-slate-400" />
                              )}
                            </span>
                          )}

                          {/* Media preview icon */}
                          {conv.lastMessage.type === 'image' && (
                            <ImageIcon className="w-3.5 h-3.5 text-slate-400 inline shrink-0" />
                          )}
                          {conv.lastMessage.type === 'audio' && (
                            <Mic className="w-3.5 h-3.5 text-slate-400 inline shrink-0" />
                          )}
                          {conv.lastMessage.type === 'document' && (
                            <FileText className="w-3.5 h-3.5 text-slate-400 inline shrink-0" />
                          )}

                          <span className="truncate">
                            {conv.lastMessage.content ||
                              (conv.lastMessage.type === 'image'
                                ? 'Photo'
                                : conv.lastMessage.type === 'audio'
                                ? 'Voice note'
                                : 'Document')}
                          </span>
                        </>
                      ) : (
                        <span className="italic text-slate-500">No messages yet</span>
                      )}
                    </div>

                    {/* Unread badge */}
                    {conv.unreadCount > 0 && (
                      <span className="shrink-0 ml-2 px-1.5 py-0.5 rounded-full bg-[#25d366] text-[#111b21] text-[11px] font-bold min-w-[20px] text-center">
                        {conv.unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Role Notice */}
      <div
        className={`px-4 py-2 border-t text-[11px] flex items-center justify-between ${
          darkMode ? 'bg-[#182229] border-[#222e35] text-slate-400' : 'bg-[#f0f2f5] border-[#e9edef] text-slate-600'
        }`}
      >
        <span className="flex items-center gap-1 truncate">
          <Shield className="w-3 h-3 text-emerald-400" />
          RBAC Protected Messaging
        </span>
        <span className="font-semibold text-emerald-400 capitalize">
          {currentUser.role.replace('_', ' ')}
        </span>
      </div>
    </div>
  );
};
