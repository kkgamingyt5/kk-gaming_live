import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { useChat } from '../../context/ChatContext.tsx';
import {
  Phone,
  Video,
  Search,
  MoreVertical,
  Paperclip,
  Smile,
  Mic,
  Send,
  Check,
  CheckCheck,
  Image as ImageIcon,
  FileText,
  Play,
  Pause,
  Crown,
  Shield,
  User as UserIcon,
  X,
  Download,
  AlertCircle,
  Square,
  Lock,
} from 'lucide-react';
import type { Message, UserRole } from '../../types/index.ts';

interface ChatAreaProps {
  onStartCall: (type: 'audio' | 'video', targetName: string) => void;
  onOpenNewChatModal: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({ onStartCall, onOpenNewChatModal }) => {
  const { currentUser, darkMode } = useAuth();
  const {
    activeConversation,
    messages,
    sendMessage,
    notifyTyping,
    isTypingMap,
    isLoadingMessages,
  } = useChat();

  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Audio voice note simulation state
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const recordingTimerRef = useRef<any>(null);

  // Audio playback state
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTypingMap]);

  if (!currentUser) return null;

  // Active recipient
  const recipient = activeConversation?.participants.find((p) => p.id !== currentUser.id);

  // Handle typing notification
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
    notifyTyping(true);

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      notifyTyping(false);
    }, 2000);
  };

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;

    const text = inputText;
    setInputText('');
    notifyTyping(false);
    await sendMessage(text, 'text');
  };

  // Voice note recording simulation
  const startRecording = () => {
    setIsRecording(true);
    setRecordDuration(0);
    recordingTimerRef.current = setInterval(() => {
      setRecordDuration((prev) => prev + 1);
    }, 1000);
  };

  const cancelRecording = () => {
    clearInterval(recordingTimerRef.current);
    setIsRecording(false);
    setRecordDuration(0);
  };

  const sendVoiceNote = async () => {
    clearInterval(recordingTimerRef.current);
    const duration = recordDuration > 0 ? recordDuration : 3;
    setIsRecording(false);
    setRecordDuration(0);

    await sendMessage(`Voice note (${duration}s)`, 'audio', {
      url: 'https://actions.google.com/sounds/v1/speech/greeting.ogg',
      duration,
      fileName: `Voice_note_${Date.now()}.m4a`,
    });
  };

  // Send photo attachment
  const sendImageAttachment = async (url: string, caption: string) => {
    setShowAttachMenu(false);
    await sendMessage(caption, 'image', {
      url,
      fileName: 'attachment.jpg',
    });
  };

  // Send document attachment
  const sendDocumentAttachment = async (name: string, size: string) => {
    setShowAttachMenu(false);
    await sendMessage(name, 'document', {
      url: '#',
      fileName: name,
      fileSize: size,
    });
  };

  const toggleAudioPlay = (msgId: string) => {
    if (playingAudioId === msgId) {
      setPlayingAudioId(null);
    } else {
      setPlayingAudioId(msgId);
      // Auto stop after 5s simulation
      setTimeout(() => {
        setPlayingAudioId(null);
      }, 5000);
    }
  };

  const formatAudioTime = (sec?: number) => {
    if (!sec) return '0:05';
    const m = Math.floor(sec / 64);
    const s = sec % 64;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const formatMsgTime = (timestamp: string) => {
    try {
      const d = new Date(timestamp);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  const getRoleBadge = (role?: UserRole) => {
    switch (role) {
      case 'super_admin':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
            <Crown className="w-3 h-3 text-amber-400" />
            Super Admin (Creator)
          </span>
        );
      case 'secondary_admin':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
            <Shield className="w-3 h-3 text-emerald-400" />
            Secondary Admin
          </span>
        );
      case 'general_user':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-full border border-blue-500/30">
            <UserIcon className="w-3 h-3 text-blue-400" />
            General User
          </span>
        );
    }
  };

  // Emojis collection
  const quickEmojis = ['😊', '👍', '❤️', '🙏', '🔥', '🎉', '🚀', '💯', '👑', '🛡️', '✅', '👋'];

  // Empty state when no conversation is selected
  if (!activeConversation) {
    return (
      <div
        className={`flex-1 flex flex-col items-center justify-center p-8 text-center border-b-[6px] border-emerald-500 ${
          darkMode ? 'bg-[#222e35] text-[#e9edef]' : 'bg-[#f0f2f5] text-[#41525d]'
        }`}
      >
        <div className="max-w-md flex flex-col items-center">
          <div className="relative mb-4">
            <img
              src="/kk_gaming_logo.jpg"
              alt="KK Gaming Live Logo"
              className="w-24 h-24 rounded-full object-cover ring-4 ring-amber-500/80 shadow-2xl"
            />
            <span className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-emerald-500 text-slate-950 ring-2 ring-[#222e35]">
              <Crown className="w-4 h-4 text-slate-950 fill-current" />
            </span>
          </div>
          <h2 className="text-2xl font-bold mb-1 tracking-tight text-white">KK Gaming Live</h2>
          <p className="text-xs font-semibold text-emerald-400 mb-2 uppercase tracking-wider">
            Official WhatsApp Store & AdminGuard
          </p>
          <p className="text-xs text-slate-400 mb-6 text-center max-w-sm">
            Enterprise messaging platform with strict Role-Based Access Control and immutable Super Admin safeguards.
          </p>

          <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/60 text-xs text-left text-slate-300 space-y-2 mb-6">
            <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              Active Permission Model:
            </div>
            <p>• Super Admin has immutable owner status and can appoint Secondary Admins.</p>
            <p>• Secondary Admins answer customer queries but cannot modify Super Admin.</p>
            <p>• General Users can strictly only initiate 1-on-1 chats with authorized Admins.</p>
          </div>

          <button
            onClick={onOpenNewChatModal}
            className="px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm flex items-center gap-2 shadow-lg transition-all"
          >
            {currentUser.role === 'general_user' ? 'Message Support Admin' : 'Start New Conversation'}
          </button>
        </div>
      </div>
    );
  }

  const isRecipientTyping = recipient ? isTypingMap[activeConversation.id] : false;

  return (
    <div
      className={`flex-1 flex flex-col h-full overflow-hidden ${
        darkMode ? 'bg-[#0b141a]' : 'bg-[#efeae2]'
      }`}
    >
      {/* Top Header */}
      <div
        className={`px-4 py-2.5 flex items-center justify-between border-b shrink-0 z-10 ${
          darkMode ? 'bg-[#202c33] border-[#222e35] text-[#e9edef]' : 'bg-[#f0f2f5] border-[#e9edef] text-[#111b21]'
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={
                recipient?.avatar ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
              }
              alt={recipient?.name || 'Contact'}
              className="w-10 h-10 rounded-full object-cover"
            />
            {recipient?.isOnline && (
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-[#202c33]" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-sm leading-tight">{recipient?.name || 'Support'}</h3>
              {getRoleBadge(recipient?.role)}
            </div>
            <div className="text-[11px] text-slate-400">
              {isRecipientTyping ? (
                <span className="text-emerald-400 font-medium italic">typing...</span>
              ) : recipient?.isOnline ? (
                <span className="text-emerald-400 font-medium">online</span>
              ) : (
                <span>last seen {recipient?.lastSeen || 'recently'}</span>
              )}
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-2 text-slate-400">
          <button
            onClick={() => onStartCall('video', recipient?.name || 'Support')}
            className="p-2 rounded-full hover:bg-slate-700/30 hover:text-slate-200 transition-colors"
            title="Video Call"
          >
            <Video className="w-5 h-5" />
          </button>
          <button
            onClick={() => onStartCall('audio', recipient?.name || 'Support')}
            className="p-2 rounded-full hover:bg-slate-700/30 hover:text-slate-200 transition-colors"
            title="Voice Call"
          >
            <Phone className="w-5 h-5" />
          </button>
          <div className="w-[1px] h-5 bg-slate-700/50 mx-1" />
          <button
            className="p-2 rounded-full hover:bg-slate-700/30 hover:text-slate-200 transition-colors"
            title="Search in chat"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            className="p-2 rounded-full hover:bg-slate-700/30 hover:text-slate-200 transition-colors"
            title="More options"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Canvas */}
      <div
        className={`flex-1 overflow-y-auto px-4 py-4 space-y-3 ${
          darkMode ? 'wa-chat-bg-dark' : 'wa-chat-bg-light'
        }`}
      >
        {/* End-to-end encryption / RBAC notice */}
        <div className="flex justify-center my-2">
          <div className="max-w-md px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] text-center flex items-center justify-center gap-1.5 shadow-xs">
            <Lock className="w-3 h-3 text-amber-400 shrink-0" />
            <span>Messages are secured by AdminGuard RBAC. Only verified Admins and the recipient have access.</span>
          </div>
        </div>

        {/* Date divider */}
        <div className="flex justify-center my-3">
          <span
            className={`px-3 py-1 rounded-md text-[11px] font-medium uppercase tracking-wider ${
              darkMode ? 'bg-[#182229] text-slate-400' : 'bg-white/80 text-slate-600 shadow-xs'
            }`}
          >
            Today
          </span>
        </div>

        {isLoadingMessages ? (
          <div className="text-center py-6 text-slate-400 text-xs">Loading secure message history...</div>
        ) : (
          messages.map((msg) => {
            const isOutgoing = msg.senderId === currentUser.id;

            return (
              <div
                key={msg.id}
                className={`flex ${isOutgoing ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[75%] sm:max-w-[65%] rounded-xl px-3 py-2 text-sm shadow-xs relative transition-all ${
                    isOutgoing
                      ? darkMode
                        ? 'bg-[#005c4b] text-[#e9edef] rounded-tr-xs'
                        : 'bg-[#d9fdd3] text-[#111b21] rounded-tr-xs'
                      : darkMode
                      ? 'bg-[#202c33] text-[#e9edef] rounded-tl-xs'
                      : 'bg-[#ffffff] text-[#111b21] rounded-tl-xs'
                  }`}
                >
                  {/* Sender Name in group/admin context */}
                  {!isOutgoing && (
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 mb-1">
                      <span>{msg.senderName}</span>
                      {msg.senderRole === 'super_admin' && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                          Super Admin
                        </span>
                      )}
                      {msg.senderRole === 'secondary_admin' && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                          Support
                        </span>
                      )}
                    </div>
                  )}

                  {/* Render based on message type */}
                  {msg.type === 'text' && (
                    <p className="whitespace-pre-wrap break-words text-[13.5px] leading-relaxed">
                      {msg.content}
                    </p>
                  )}

                  {msg.type === 'image' && msg.media && (
                    <div className="space-y-1.5">
                      <img
                        src={msg.media.url}
                        alt="attachment"
                        onClick={() => setLightboxImage(msg.media?.url || null)}
                        className="rounded-lg max-h-60 w-full object-cover cursor-pointer hover:opacity-95 transition-opacity"
                      />
                      {msg.content && <p className="text-xs pt-1">{msg.content}</p>}
                    </div>
                  )}

                  {msg.type === 'audio' && msg.media && (
                    <div className="flex items-center gap-3 py-1 min-w-[200px] sm:min-w-[240px]">
                      <button
                        onClick={() => toggleAudioPlay(msg.id)}
                        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 ${
                          isOutgoing
                            ? 'bg-emerald-700 text-white'
                            : 'bg-emerald-500 text-slate-900'
                        }`}
                      >
                        {playingAudioId === msg.id ? (
                          <Pause className="w-4 h-4 fill-current" />
                        ) : (
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        )}
                      </button>

                      {/* Waveform Visualization Bars */}
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-1 h-5">
                          {[40, 70, 30, 90, 60, 45, 80, 50, 65, 35, 75, 40, 60, 90, 50].map(
                            (height, idx) => (
                              <span
                                key={idx}
                                style={{ height: `${height}%` }}
                                className={`w-1 rounded-full ${
                                  playingAudioId === msg.id && idx < 8
                                    ? 'bg-[#53bdeb]'
                                    : isOutgoing
                                    ? 'bg-white/60'
                                    : 'bg-slate-400'
                                }`}
                              />
                            )
                          )}
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-400">
                          <span>
                            {playingAudioId === msg.id ? 'Playing...' : formatAudioTime(msg.media.duration)}
                          </span>
                          <span className="flex items-center gap-0.5">
                            <Mic className="w-2.5 h-2.5 text-emerald-400" />
                            Voice Note
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {msg.type === 'document' && msg.media && (
                    <div
                      className={`flex items-center gap-3 p-2.5 rounded-lg ${
                        isOutgoing ? 'bg-emerald-800/40' : 'bg-slate-800/40'
                      }`}
                    >
                      <div className="p-2 rounded bg-emerald-500/20 text-emerald-400">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-xs truncate">
                          {msg.media.fileName || 'Attachment Document'}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {msg.media.fileSize || '1.2 MB'} • PDF
                        </div>
                      </div>
                      <button
                        onClick={() => alert(`Downloading document: ${msg.media?.fileName}`)}
                        className="p-1.5 rounded-full hover:bg-slate-700/50 text-slate-300"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* Message Timestamp & Double Blue Ticks */}
                  <div className="flex items-center justify-end gap-1 mt-1 text-[10px] text-slate-400 select-none">
                    <span>{formatMsgTime(msg.timestamp)}</span>
                    {isOutgoing && (
                      <span>
                        {msg.status === 'read' ? (
                          <span title="Read (Double blue ticks)">
                            <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb]" />
                          </span>
                        ) : msg.status === 'delivered' ? (
                          <span title="Delivered (Double grey ticks)">
                            <CheckCheck className="w-3.5 h-3.5 text-slate-400" />
                          </span>
                        ) : (
                          <span title="Sent (Single tick)">
                            <Check className="w-3.5 h-3.5 text-slate-400" />
                          </span>
                        )}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Attachment Popover */}
      {showAttachMenu && (
        <div
          className={`px-4 py-3 border-t grid grid-cols-2 sm:grid-cols-4 gap-2 ${
            darkMode ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f0f2f5] border-[#e9edef]'
          }`}
        >
          <button
            onClick={() =>
              sendImageAttachment(
                'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&auto=format&fit=crop&q=80',
                'System dashboard overview screenshot'
              )
            }
            className="flex items-center gap-2 p-2 rounded-lg bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 text-xs font-medium transition-colors"
          >
            <ImageIcon className="w-4 h-4 text-emerald-400" />
            Send Photo / Screenshot
          </button>
          <button
            onClick={() =>
              sendDocumentAttachment('Audit_Report_Compliance_2026.pdf', '2.4 MB')
            }
            className="flex items-center gap-2 p-2 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 text-xs font-medium transition-colors"
          >
            <FileText className="w-4 h-4 text-blue-400" />
            Send PDF Document
          </button>
          <button
            onClick={() =>
              sendDocumentAttachment('User_Terms_Policy.docx', '840 KB')
            }
            className="flex items-center gap-2 p-2 rounded-lg bg-purple-600/10 hover:bg-purple-600/20 text-purple-400 text-xs font-medium transition-colors"
          >
            <FileText className="w-4 h-4 text-purple-400" />
            Send Policy Doc
          </button>
          <button
            onClick={() => setShowAttachMenu(false)}
            className="flex items-center justify-center gap-1 p-2 rounded-lg bg-slate-700/40 hover:bg-slate-700/60 text-slate-300 text-xs font-medium transition-colors"
          >
            <X className="w-4 h-4" />
            Cancel
          </button>
        </div>
      )}

      {/* Emoji Picker Popover */}
      {showEmojiPicker && (
        <div
          className={`px-4 py-2 border-t flex flex-wrap gap-2 items-center ${
            darkMode ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f0f2f5] border-[#e9edef]'
          }`}
        >
          {quickEmojis.map((emoji) => (
            <button
              key={emoji}
              onClick={() => {
                setInputText((prev) => prev + emoji);
                setShowEmojiPicker(false);
              }}
              className="text-lg hover:scale-125 transition-transform p-1"
            >
              {emoji}
            </button>
          ))}
          <button
            onClick={() => setShowEmojiPicker(false)}
            className="text-xs text-slate-400 ml-auto hover:text-white"
          >
            Close
          </button>
        </div>
      )}

      {/* WhatsApp Input Bar */}
      <div
        className={`px-4 py-2.5 flex items-center gap-2 border-t ${
          darkMode ? 'bg-[#202c33] border-[#222e35]' : 'bg-[#f0f2f5] border-[#e9edef]'
        }`}
      >
        {isRecording ? (
          // Recording Audio active bar
          <div className="flex-1 flex items-center justify-between bg-red-950/40 border border-red-500/30 rounded-xl px-4 py-2 text-sm text-red-300">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500 animate-recording" />
              <span className="font-mono font-semibold">
                0:{recordDuration < 10 ? `0${recordDuration}` : recordDuration}
              </span>
              <span className="text-xs text-red-200/80">Recording WhatsApp Voice Note...</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={cancelRecording}
                className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-white text-xs font-medium"
              >
                Cancel
              </button>
              <button
                onClick={sendVoiceNote}
                className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 shadow-sm"
              >
                <Send className="w-3 h-3" />
                Send Audio
              </button>
            </div>
          </div>
        ) : (
          // Standard Message Input
          <>
            {/* Emoji toggle */}
            <button
              type="button"
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              className="text-slate-400 hover:text-slate-200 p-1.5 transition-colors"
              title="Add Emoji"
            >
              <Smile className="w-6 h-6" />
            </button>

            {/* Paperclip attachment menu */}
            <button
              type="button"
              onClick={() => setShowAttachMenu((prev) => !prev)}
              className="text-slate-400 hover:text-slate-200 p-1.5 transition-colors"
              title="Attach media or document"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {/* Input form */}
            <form onSubmit={handleSend} className="flex-1 flex items-center">
              <input
                type="text"
                value={inputText}
                onChange={handleInputChange}
                placeholder="Type a message"
                className={`w-full px-4 py-2.5 rounded-lg text-sm focus:outline-hidden transition-colors ${
                  darkMode
                    ? 'bg-[#2a3942] text-[#e9edef] placeholder:text-slate-400'
                    : 'bg-white text-[#111b21] placeholder:text-slate-500 shadow-xs'
                }`}
              />
            </form>

            {/* Mic or Send button */}
            {inputText.trim() ? (
              <button
                onClick={() => handleSend()}
                className="p-2.5 rounded-full bg-[#00a884] hover:bg-[#008f6f] text-white transition-all transform active:scale-95 shadow-md"
                title="Send message"
              >
                <Send className="w-4 h-4 fill-current ml-0.5" />
              </button>
            ) : (
              <button
                onClick={startRecording}
                className="p-2.5 rounded-full text-slate-400 hover:text-slate-200 hover:bg-slate-700/30 transition-all"
                title="Record voice note"
              >
                <Mic className="w-5 h-5" />
              </button>
            )}
          </>
        )}
      </div>

      {/* Image Lightbox Modal */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <img
              src={lightboxImage}
              alt="Enlarged attachment"
              className="max-h-[85vh] max-w-full rounded-xl object-contain shadow-2xl"
            />
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-2 right-2 bg-slate-900/80 text-white p-2 rounded-full hover:bg-slate-900"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
