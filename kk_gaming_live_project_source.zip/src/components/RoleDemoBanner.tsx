import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useChat } from '../context/ChatContext.tsx';
import { Shield, Crown, User as UserIcon, AlertTriangle, ArrowRightLeft, Sparkles, CheckCircle2, Lock } from 'lucide-react';
import type { UserRole } from '../types/index.ts';
import { PWAInstallButton } from './pwa/PWAInstallButton.tsx';

interface RoleDemoBannerProps {
  onOpenAuthModal: () => void;
}

export const RoleDemoBanner: React.FC<RoleDemoBannerProps> = ({ onOpenAuthModal }) => {
  const { currentUser, demoAccounts, switchUser, systemStats } = useAuth();
  const { setActiveTab } = useChat();
  const [showRulesModal, setShowRulesModal] = useState(false);

  if (!currentUser) return null;

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            Super Admin (Creator / Owner)
          </span>
        );
      case 'secondary_admin':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Secondary Admin (Support)
          </span>
        );
      case 'general_user':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/40">
            <UserIcon className="w-3.5 h-3.5 text-blue-400" />
            General User
          </span>
        );
    }
  };

  return (
    <>
      <div className="bg-slate-900 border-b border-slate-800 text-slate-200 px-4 py-2.5 text-sm">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Active User Indicator */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-1">
                <ArrowRightLeft className="w-3.5 h-3.5 text-emerald-400" />
                Active Profile:
              </span>
              <div className="flex items-center gap-2 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-5 h-5 rounded-full object-cover"
                />
                <span className="font-medium text-white text-xs sm:text-sm">{currentUser.name}</span>
                {getRoleBadge(currentUser.role)}
              </div>
            </div>

            {/* Scale badge */}
            <span className="hidden lg:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/30 text-emerald-400 text-xs font-medium">
              <Sparkles className="w-3 h-3" />
              Scale: {systemStats ? `${systemStats.totalUsers.toLocaleString()} Users` : '10,500 Users'}
            </span>
          </div>

          {/* Quick 1-Click Role Switcher */}
          <div className="flex items-center flex-wrap gap-1.5">
            <span className="text-xs text-slate-400 mr-1 hidden sm:inline">1-Click Switch:</span>
            {demoAccounts.map((account) => {
              const isActive = account.id === currentUser.id;
              return (
                <button
                  key={account.id}
                  onClick={() => switchUser(account)}
                  className={`text-xs px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 font-medium ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-sm ring-1 ring-emerald-400'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700'
                  }`}
                  title={`Switch to ${account.name} (${account.role})`}
                >
                  {account.role === 'super_admin' && <Crown className="w-3 h-3 text-amber-300" />}
                  {account.role === 'secondary_admin' && <Shield className="w-3 h-3 text-emerald-300" />}
                  {account.role === 'general_user' && <UserIcon className="w-3 h-3 text-blue-300" />}
                  <span>{account.name === 'KK Gaming Live' ? 'KK Gaming' : account.name.split(' ')[0]}</span>
                  <span className="text-[10px] opacity-75 hidden md:inline">
                    ({account.role === 'super_admin' ? 'Owner' : account.role === 'secondary_admin' ? 'Sec Admin' : 'User'})
                  </span>
                </button>
              );
            })}

            <button
              onClick={() => setShowRulesModal(true)}
              className="text-xs px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 font-medium transition-all ml-1"
            >
              RBAC Rules
            </button>

            <button
              onClick={onOpenAuthModal}
              className="text-xs px-2.5 py-1 rounded-md bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-500/40 font-medium transition-all"
            >
              + Login / Register
            </button>

            <PWAInstallButton variant="header" />
          </div>
        </div>

        {/* Dynamic rule reminder banner depending on active role */}
        <div className="max-w-7xl mx-auto mt-1.5 pt-1.5 border-t border-slate-800/80 text-xs flex flex-wrap items-center justify-between gap-2 text-slate-400">
          <div className="flex items-center gap-1.5">
            {currentUser.role === 'super_admin' && (
              <span className="text-amber-400 font-medium flex items-center gap-1">
                <Crown className="w-3.5 h-3.5 inline" />
                Super Admin Privilege:
                <span className="text-slate-300 font-normal">
                  You hold ultimate owner authority. You can appoint/demote Secondary Admins, kick users, broadcast to all 10k users, and your account CANNOT be modified or kicked by anyone.
                </span>
              </span>
            )}
            {currentUser.role === 'secondary_admin' && (
              <span className="text-emerald-400 font-medium flex items-center gap-1">
                <Shield className="w-3.5 h-3.5 inline" />
                Secondary Admin Status:
                <span className="text-slate-300 font-normal">
                  Appointed by Super Admin. You can answer General User queries and moderate general users. You CANNOT kick or alter the Super Admin.
                </span>
              </span>
            )}
            {currentUser.role === 'general_user' && (
              <span className="text-blue-400 font-medium flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 inline" />
                Policy Enforcement:
                <span className="text-slate-300 font-normal">
                  You can ONLY initiate 1-on-1 private messages with Admins. Direct messaging other General Users is restricted.
                </span>
              </span>
            )}
          </div>

          {(currentUser.role === 'super_admin' || currentUser.role === 'secondary_admin') && (
            <button
              onClick={() => setActiveTab('admin_dashboard')}
              className="text-xs text-emerald-400 hover:text-emerald-300 underline font-medium"
            >
              Go to Admin Management Panel →
            </button>
          )}
        </div>
      </div>

      {/* RBAC Rules & Architecture Explanation Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 text-slate-200 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">RBAC Permissions & System Safeguards</h3>
                  <p className="text-xs text-slate-400">Strict hierarchical access control specifications</p>
                </div>
              </div>
              <button
                onClick={() => setShowRulesModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="mt-5 space-y-4 text-sm">
              {/* Super Admin */}
              <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-500/30">
                <div className="flex items-center gap-2 font-semibold text-amber-300 mb-2">
                  <Crown className="w-4 h-4" />
                  1. Super Admin (The Creator / Real Owner: KK Gaming Live)
                </div>
                <ul className="space-y-1.5 text-xs text-slate-300 pl-5 list-disc">
                  <li>Ultimate authority over the entire messaging platform and database.</li>
                  <li>Can create, assign, and promote any General User to "Secondary Admin".</li>
                  <li>Can demote or kick out Secondary Admins and General Users.</li>
                  <li className="font-semibold text-amber-400">
                    CANNOT BE KICKED OUT, BANNED, OR DEMOTED BY ANYONE, including Secondary Admins. (Enforced rigidly in backend API & kernel safeguards).
                  </li>
                  <li>Full access to global 10,000+ user directory, system metrics, and audit logs.</li>
                </ul>
              </div>

              {/* Secondary Admin */}
              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
                <div className="flex items-center gap-2 font-semibold text-emerald-300 mb-2">
                  <Shield className="w-4 h-4" />
                  2. Secondary Admin (Appointed Support Leads)
                </div>
                <ul className="space-y-1.5 text-xs text-slate-300 pl-5 list-disc">
                  <li>Appointed by Super Admin to manage user support queries and customer care.</li>
                  <li>Receives and responds to private 1-on-1 messages from General Users.</li>
                  <li className="font-semibold text-red-400">
                    CANNOT kick, demote, or modify the status of the Super Admin (Hardcoded guard logic).
                  </li>
                  <li>Can manage and moderate General Users (resolve queries, mute/ban abusive users).</li>
                </ul>
              </div>

              {/* General User */}
              <div className="p-4 rounded-xl bg-blue-950/20 border border-blue-500/30">
                <div className="flex items-center gap-2 font-semibold text-blue-300 mb-2">
                  <UserIcon className="w-4 h-4" />
                  3. General User
                </div>
                <ul className="space-y-1.5 text-xs text-slate-300 pl-5 list-disc">
                  <li className="font-semibold text-blue-300">
                    Users CANNOT initiate direct messages with other General Users.
                  </li>
                  <li>Users can ONLY initiate 1-on-1 private messages with Admins (Super Admin or Secondary Admins).</li>
                  <li>Users can view and receive broadcast announcements sent by Admins.</li>
                  <li>Automatic assignment to General User upon phone or email registration.</li>
                </ul>
              </div>

              {/* High Scale Architecture Note */}
              <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs">
                <div className="font-semibold text-white mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Scalability Engine: 10,500 Active Users Indexed
                </div>
                <p className="text-slate-300">
                  Pre-indexed in-memory architecture with sub-10ms query execution, paginated cursor support, and real-time WebSockets for instant message delivery, double blue ticks, and broadcast alerts.
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowRulesModal(false)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-medium transition-colors"
              >
                Close & Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
