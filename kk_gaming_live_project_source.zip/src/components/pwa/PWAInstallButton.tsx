import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall.ts';
import { Download, Smartphone, X, CheckCircle2, Share } from 'lucide-react';

interface PWAInstallButtonProps {
  className?: string;
  variant?: 'banner' | 'sidebar' | 'header';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  className = '',
  variant = 'header',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  // If already running as installed standalone app, suppress
  if (isInstalled) {
    return null;
  }

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      await install();
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <>
      {/* Chromium / Android / Desktop button */}
      {isInstallable && (
        <button
          onClick={handleInstallClick}
          disabled={isInstalling}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs transition-all shadow-sm ${
            variant === 'sidebar'
              ? 'w-full justify-center bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          } ${className}`}
          title="Install KK Gaming Live App to Home Screen"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isInstalling ? 'Installing...' : 'Install App (PWA)'}</span>
        </button>
      )}

      {/* iOS Safari Fallback */}
      {isIOS && !isInstallable && (
        <button
          onClick={() => setShowIOSGuide(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs transition-all shadow-sm ${
            variant === 'sidebar'
              ? 'w-full justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
          } ${className}`}
          title="Install on iPhone / iPad"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>Install on iOS</span>
        </button>
      )}

      {/* If browser hasn't fired beforeinstallprompt yet (or user wants instructions) */}
      {!isInstallable && !isIOS && variant === 'sidebar' && (
        <button
          onClick={() => alert("To install: In Chrome or Edge, click the 'Install' icon (computer with down arrow) in your browser address bar, or open browser menu ⋮ and click 'Install KK Gaming Live'.")}
          className={`flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors ${className}`}
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span>App Install Options</span>
        </button>
      )}

      {/* iOS Instructions Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Install on iPhone / iPad</h3>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="my-5 space-y-3.5 text-xs text-slate-300">
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
                  <Share className="w-4 h-4" />
                </span>
                <div>
                  <span className="font-semibold text-white">Step 1:</span>
                  <p className="mt-0.5">Tap the <strong>Share</strong> button in your Safari bottom navigation bar.</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </span>
                <div>
                  <span className="font-semibold text-white">Step 2:</span>
                  <p className="mt-0.5">Scroll down the menu options and tap <strong>Add to Home Screen</strong>.</p>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0">
                  <Download className="w-4 h-4" />
                </span>
                <div>
                  <span className="font-semibold text-white">Step 3:</span>
                  <p className="mt-0.5">Tap <strong>Add</strong> at top right. The app icon will appear directly on your home screen!</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors"
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </>
  );
};
