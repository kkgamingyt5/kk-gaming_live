import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { User, SystemStats } from '../types/index.ts';
import { api, setApiUserId, realtimeSocket } from '../services/api.ts';

interface AuthContextType {
  currentUser: User | null;
  demoAccounts: User[];
  isLoading: boolean;
  darkMode: boolean;
  systemStats: SystemStats | null;
  toggleDarkMode: () => void;
  switchUser: (user: User) => Promise<void>;
  login: (params: { userId?: string; email?: string; phone?: string }) => Promise<void>;
  signup: (params: { name: string; phone?: string; email?: string; about?: string }) => Promise<void>;
  updateUserProfile: (data: { name?: string; avatar?: string; about?: string; phone?: string }) => Promise<void>;
  refreshCurrentUser: () => Promise<void>;
  refreshStats: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const PRESET_DEMO_ACCOUNTS: User[] = [
  {
    id: 'saifur-super-admin-01',
    name: 'KK Gaming Live',
    phone: '+1 (555) 019-2834',
    email: 'saifurrahman03145155799@gmail.com',
    avatar: '/kk_gaming_logo.jpg',
    role: 'super_admin',
    status: 'active',
    about: '🎮 KK Gaming Live | Creator & System Super Admin. Full Owner privileges.',
    createdAt: '2024-01-01T00:00:00.000Z',
    lastSeen: 'Online',
    isOnline: true,
    isImmutableOwner: true,
  },
  {
    id: 'admin-sarah-02',
    name: 'Sarah Jenkins',
    phone: '+1 (555) 014-9921',
    email: 'sarah.jenkins@guardchat.io',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    role: 'secondary_admin',
    status: 'active',
    about: '🛡️ Secondary Admin | Customer Support Lead',
    createdAt: '2024-02-10T11:20:00.000Z',
    lastSeen: 'Online',
    isOnline: true,
  },
  {
    id: 'user-alex-04',
    name: 'Alex Morgan',
    phone: '+1 (555) 012-3456',
    email: 'alex.morgan@example.com',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    role: 'general_user',
    status: 'active',
    about: 'Available | Standard verified user',
    createdAt: '2024-04-12T14:32:00.000Z',
    lastSeen: 'Online',
    isOnline: true,
  },
  {
    id: 'user-priya-05',
    name: 'Priya Sharma',
    phone: '+1 (555) 017-8823',
    email: 'priya.s@example.com',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    role: 'general_user',
    status: 'active',
    about: 'Hey there! I am using AdminGuard WhatsApp.',
    createdAt: '2024-05-18T09:45:00.000Z',
    lastSeen: 'Online',
    isOnline: true,
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(PRESET_DEMO_ACCOUNTS[0]);
  const [demoAccounts, setDemoAccounts] = useState<User[]>(PRESET_DEMO_ACCOUNTS);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('adminguard_theme') === 'dark' || true; // WhatsApp dark mode by default looks sleek
  });
  const [systemStats, setSystemStats] = useState<SystemStats | null>(null);

  const toggleDarkMode = () => {
    setDarkMode((prev) => {
      const next = !prev;
      localStorage.setItem('adminguard_theme', next ? 'dark' : 'light');
      return next;
    });
  };

  const refreshStats = useCallback(async () => {
    try {
      const stats = await api.getStats();
      setSystemStats(stats);
    } catch (e) {
      console.error('Failed to load system stats', e);
    }
  }, []);

  const refreshCurrentUser = useCallback(async () => {
    try {
      const res = await api.getCurrentUser();
      if (res.user) {
        setCurrentUser(res.user);
      }
    } catch (e) {
      console.error('Failed to refresh current user', e);
    }
  }, []);

  // Initialize auth
  useEffect(() => {
    async function init() {
      setIsLoading(true);
      try {
        const savedId = localStorage.getItem('adminguard_user_id') || PRESET_DEMO_ACCOUNTS[0].id;
        setApiUserId(savedId);
        realtimeSocket.connect(savedId);

        const res = await api.getCurrentUser();
        setCurrentUser(res.user);
        await refreshStats();
      } catch (e) {
        console.error('Auth initialization error', e);
      } finally {
        setIsLoading(false);
      }
    }

    init();
  }, [refreshStats]);

  // Listen to realtime role updates or account suspension
  useEffect(() => {
    const unsubscribe = realtimeSocket.subscribe((event) => {
      if (event.type === 'role_updated') {
        refreshCurrentUser();
        refreshStats();
      } else if (event.type === 'account_suspended') {
        alert('Your account has been suspended by an administrator.');
        refreshCurrentUser();
      }
    });

    return () => {
      unsubscribe();
    };
  }, [refreshCurrentUser, refreshStats]);

  const switchUser = async (user: User) => {
    setIsLoading(true);
    try {
      setApiUserId(user.id);
      localStorage.setItem('adminguard_user_id', user.id);
      realtimeSocket.connect(user.id);
      setCurrentUser(user);
      await refreshStats();
    } catch (e) {
      console.error('Switch user error', e);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (params: { userId?: string; email?: string; phone?: string }) => {
    setIsLoading(true);
    try {
      const res = await api.login(params);
      if (res.user) {
        setApiUserId(res.user.id);
        localStorage.setItem('adminguard_user_id', res.user.id);
        realtimeSocket.connect(res.user.id);
        setCurrentUser(res.user);
        await refreshStats();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (params: { name: string; phone?: string; email?: string; about?: string }) => {
    setIsLoading(true);
    try {
      const res = await api.signup(params);
      if (res.user) {
        setApiUserId(res.user.id);
        localStorage.setItem('adminguard_user_id', res.user.id);
        realtimeSocket.connect(res.user.id);
        setCurrentUser(res.user);
        await refreshStats();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserProfile = async (data: { name?: string; avatar?: string; about?: string; phone?: string }) => {
    if (!currentUser) return;
    setIsLoading(true);
    try {
      const res = await api.updateProfile(currentUser.id, data);
      if (res.user) {
        setCurrentUser(res.user);
        setDemoAccounts((prev) =>
          prev.map((acc) => (acc.id === res.user.id ? { ...acc, ...res.user } : acc))
        );
        await refreshStats();
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        demoAccounts,
        isLoading,
        darkMode,
        systemStats,
        toggleDarkMode,
        switchUser,
        login,
        signup,
        updateUserProfile,
        refreshCurrentUser,
        refreshStats,
      }}
    >
      <div className={darkMode ? 'dark' : ''}>{children}</div>
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
