import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type {
  Conversation,
  Message,
  BroadcastAnnouncement,
} from '../types/index.ts';
import { api, realtimeSocket } from '../services/api.ts';
import { useAuth } from './AuthContext.tsx';

interface ChatContextType {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  messages: Message[];
  broadcasts: BroadcastAnnouncement[];
  unreadBroadcastsCount: number;
  isTypingMap: Record<string, boolean>;
  activeTab: 'chats' | 'admin_dashboard' | 'broadcasts';
  isLoadingMessages: boolean;
  setActiveTab: (tab: 'chats' | 'admin_dashboard' | 'broadcasts') => void;
  selectConversation: (conv: Conversation | null) => Promise<void>;
  sendMessage: (
    content: string,
    type?: 'text' | 'image' | 'audio' | 'document',
    media?: any
  ) => Promise<void>;
  startChatWithUser: (targetUserId: string) => Promise<Conversation>;
  sendBroadcast: (
    title: string,
    content: string,
    priority?: 'normal' | 'important' | 'urgent'
  ) => Promise<void>;
  notifyTyping: (isTyping: boolean) => void;
  refreshConversations: () => Promise<void>;
  refreshBroadcasts: () => Promise<void>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, refreshStats } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [broadcasts, setBroadcasts] = useState<BroadcastAnnouncement[]>([]);
  const [unreadBroadcastsCount, setUnreadBroadcastsCount] = useState<number>(0);
  const [isTypingMap, setIsTypingMap] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'chats' | 'admin_dashboard' | 'broadcasts'>('chats');
  const [isLoadingMessages, setIsLoadingMessages] = useState<boolean>(false);

  const refreshConversations = useCallback(async () => {
    if (!currentUser) return;
    try {
      const res = await api.getConversations();
      setConversations(res.conversations);
    } catch (e) {
      console.error('Failed to load conversations', e);
    }
  }, [currentUser]);

  const refreshBroadcasts = useCallback(async () => {
    try {
      const res = await api.getBroadcasts();
      setBroadcasts(res.broadcasts);
    } catch (e) {
      console.error('Failed to load broadcasts', e);
    }
  }, []);

  // Fetch initial conversations & broadcasts when current user changes
  useEffect(() => {
    if (currentUser) {
      refreshConversations();
      refreshBroadcasts();
      // Reset active conversation if it does not belong to current user
      setActiveConversation((prev) => {
        if (!prev) return null;
        return prev.participantIds.includes(currentUser.id) ? prev : null;
      });
    }
  }, [currentUser, refreshConversations, refreshBroadcasts]);

  // Load messages when active conversation changes
  const selectConversation = async (conv: Conversation | null) => {
    setActiveConversation(conv);
    if (!conv) {
      setMessages([]);
      return;
    }

    setIsLoadingMessages(true);
    try {
      const res = await api.getMessages(conv.id);
      setMessages(res.messages);

      // Mark as read
      await api.markAsRead(conv.id);
      setConversations((prev) =>
        prev.map((c) => (c.id === conv.id ? { ...c, unreadCount: 0 } : c))
      );
    } catch (e) {
      console.error('Failed to load messages', e);
    } finally {
      setIsLoadingMessages(false);
    }
  };

  // Realtime Socket Listener
  useEffect(() => {
    const unsubscribe = realtimeSocket.subscribe((event) => {
      if (event.type === 'new_message') {
        const newMsg: Message = event.message;
        // If active conversation matches, append message
        if (activeConversation && activeConversation.id === event.conversationId) {
          setMessages((prev) => [...prev, newMsg]);
          api.markAsRead(event.conversationId).catch(() => {});
        }

        // Update conversations list
        setConversations((prev) => {
          const index = prev.findIndex((c) => c.id === event.conversationId);
          if (index !== -1) {
            const updated = [...prev];
            const currentConv = updated[index];
            const isCurrent = activeConversation?.id === event.conversationId;
            updated[index] = {
              ...currentConv,
              lastMessage: newMsg,
              unreadCount: isCurrent ? 0 : currentConv.unreadCount + 1,
              updatedAt: newMsg.timestamp,
            };
            return updated.sort(
              (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
            );
          } else {
            // New conversation arrived, refresh
            refreshConversations();
            return prev;
          }
        });
        refreshStats();
      } else if (event.type === 'message_sent_confirm') {
        const sentMsg: Message = event.message;
        if (activeConversation && activeConversation.id === event.conversationId) {
          setMessages((prev) => {
            if (prev.some((m) => m.id === sentMsg.id)) return prev;
            return [...prev, sentMsg];
          });
        }
        refreshConversations();
      } else if (event.type === 'messages_read') {
        // Double blue tick status update
        if (activeConversation && activeConversation.id === event.conversationId) {
          setMessages((prev) =>
            prev.map((m) =>
              m.recipientId === event.readBy ? { ...m, status: 'read', readAt: event.timestamp } : m
            )
          );
        }
      } else if (event.type === 'typing') {
        setIsTypingMap((prev) => ({
          ...prev,
          [event.conversationId]: event.isTyping,
        }));
      } else if (event.type === 'broadcast_received') {
        const newBroadcast: BroadcastAnnouncement = event.broadcast;
        setBroadcasts((prev) => [newBroadcast, ...prev]);
        setUnreadBroadcastsCount((prev) => prev + 1);
        refreshStats();
      }
    });

    return () => {
      unsubscribe();
    };
  }, [activeConversation, refreshConversations, refreshStats]);

  // Send Message
  const sendMessage = async (
    content: string,
    type: 'text' | 'image' | 'audio' | 'document' = 'text',
    media?: any
  ) => {
    if (!activeConversation || !currentUser) return;
    try {
      const res = await api.sendMessage({
        conversationId: activeConversation.id,
        content,
        type,
        media,
      });

      if (res.message) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === res.message.id)) return prev;
          return [...prev, res.message];
        });

        setConversations((prev) => {
          return prev.map((c) =>
            c.id === activeConversation.id
              ? { ...c, lastMessage: res.message, updatedAt: res.message.timestamp }
              : c
          );
        });
        refreshStats();
      }
    } catch (e: any) {
      alert(`Message error: ${e.message || 'Could not send message'}`);
    }
  };

  // Start chat with user (with client-side check)
  const startChatWithUser = async (targetUserId: string): Promise<Conversation> => {
    try {
      const res = await api.startConversation(targetUserId);
      await refreshConversations();
      await selectConversation(res.conversation);
      setActiveTab('chats');
      return res.conversation;
    } catch (e: any) {
      alert(`Access Control: ${e.message}`);
      throw e;
    }
  };

  // Send Broadcast
  const sendBroadcast = async (
    title: string,
    content: string,
    priority: 'normal' | 'important' | 'urgent' = 'normal'
  ) => {
    try {
      const res = await api.sendBroadcast({ title, content, priority });
      if (res.broadcast) {
        setBroadcasts((prev) => [res.broadcast, ...prev]);
        refreshStats();
      }
    } catch (e: any) {
      alert(`Broadcast error: ${e.message}`);
      throw e;
    }
  };

  const notifyTyping = (isTyping: boolean) => {
    if (!activeConversation || !currentUser) return;
    const recipient = activeConversation.participants.find((p) => p.id !== currentUser.id);
    if (recipient) {
      realtimeSocket.sendTyping(activeConversation.id, recipient.id, isTyping);
    }
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversation,
        messages,
        broadcasts,
        unreadBroadcastsCount,
        isTypingMap,
        activeTab,
        isLoadingMessages,
        setActiveTab,
        selectConversation,
        sendMessage,
        startChatWithUser,
        sendBroadcast,
        notifyTyping,
        refreshConversations,
        refreshBroadcasts,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
